ALTER TABLE student
DROP CONSTRAINT IF EXISTS student_gender_check;